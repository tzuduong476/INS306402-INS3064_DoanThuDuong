<?php
$x = 10;
$y = 5;

$addition = $x + $y;
$subtraction = $x - $y;
$multiplication = $x * $y;
$division = $x / $y;

echo $addition . ", " . $subtraction . ", " . $multiplication . ", " . $division;
?>