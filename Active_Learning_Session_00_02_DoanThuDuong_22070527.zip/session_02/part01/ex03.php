<?php
$string = '25.50';

$float = (float)$string;
echo gettype($float) . "(" . $float . "), ";

$int = (int)$float;
echo gettype($int) . "(" . $int . ")";
?>
