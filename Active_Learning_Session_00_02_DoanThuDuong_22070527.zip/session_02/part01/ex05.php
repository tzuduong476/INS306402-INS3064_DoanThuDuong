<?php
$input = ["Apple", "Banana", "Pear"];
echo $input[1];
?>