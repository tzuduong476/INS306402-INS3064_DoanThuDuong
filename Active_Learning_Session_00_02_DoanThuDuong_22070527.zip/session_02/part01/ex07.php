<?php
    $a = 5;      
    $b = '5';    

    $isEqual = ($a == $b) ? "True" : "False";
    $isIdentical = ($a === $b) ? "True" : "False";

    echo "Equal ($isEqual), Identical ($isIdentical)";
?>