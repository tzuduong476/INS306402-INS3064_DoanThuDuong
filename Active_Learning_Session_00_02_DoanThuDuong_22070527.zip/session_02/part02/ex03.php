<?php
    
echo "<table border='1' cellpadding='10'>";
echo "<tr><th></th>";

for ($col = 1; $col <= 5; $col++) {
    echo "<th>$col</th>";
}
echo "</tr>";

for ($row = 1; $row <= 5; $row++) {
    echo "<tr><th>$row</th>";
    for ($col = 1; $col <= 5; $col++) {
        $result = $row * $col;
        echo "<td>$result</td>";
    }
    echo "</tr>";
}

echo "</table>";
?>