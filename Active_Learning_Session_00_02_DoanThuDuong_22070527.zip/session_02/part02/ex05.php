<?php
$num = 10;

while ($num >= 1) {
    echo $num . ", ";
    $num--;
}

echo "Liftoff!";
?>