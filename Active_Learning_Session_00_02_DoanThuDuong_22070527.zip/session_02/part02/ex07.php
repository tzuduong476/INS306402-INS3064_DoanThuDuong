<?php
    $input = [6, 7, 2, 0, 4]; 
    $output = []; 

    $length = count($input); 

    for ($i = $length - 1; $i >= 0; $i--) {
        $output[] = $input[$i]; 
    }

    echo "Output: [" . implode(", ", $output) . "]";
?>