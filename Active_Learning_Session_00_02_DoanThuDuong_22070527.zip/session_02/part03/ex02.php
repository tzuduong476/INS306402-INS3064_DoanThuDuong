<?php

    function area(float $w, float $h): float {
        return $w * $h;
    }

    $input = area(5.5, 2);

    echo number_format($input, 1); 
?>