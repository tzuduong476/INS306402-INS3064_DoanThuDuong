<?php
    
    function fmt(float $amt, string $c = '$'): string {
        return $c . number_format($amt, 2);
    }

    $input1 = fmt(50); 

    echo $input1;    
?>