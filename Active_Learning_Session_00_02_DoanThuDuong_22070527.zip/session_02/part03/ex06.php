<?php
   
    function add(int $a, int $b): int {
        return $a + $b;
    }

    $sum = add(6, 7);

?>