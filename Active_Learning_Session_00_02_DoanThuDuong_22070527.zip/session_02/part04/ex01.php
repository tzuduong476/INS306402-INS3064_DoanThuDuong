<?php

function calculateBMI($kg, $m) {
    $bmi = $kg / ($m * $m); 
    $bmi_val = number_format($bmi, 1); 

    if ($bmi < 18.5) {
        $cat = "UNDERWEIGHT";
        $btn_color = "#D76067"; 
        $text_color = "#FFFFFF"; 
    } elseif ($bmi <= 24.9) {
        $cat = "NORMAL";
        $btn_color = "#981D26";
        $text_color = "#FFFFFF"; 
    } else {
        $cat = "OVERWEIGHT";
        $btn_color = "#500E10"; 
        $text_color = "#FFFFFF"; 
    }

    return ['val' => $bmi_val, 'cat' => $cat, 'btn' => $btn_color, 'txt' => $text_color, 'kg' => $kg, 'm' => $m];
}

$data = calculateBMI(50, 1.57);
?>

<style>
    body { 
        background-color: #FAF3F3; 
        display: flex; 
        justify-content: center; 
        align-items: center; 
        height: 100vh; 
        font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; 
        margin: 0; 
    }

    .bmi-card { 
        background: #FFFFFF; 
        padding: 50px 40px; 
        border-radius: 40px; 
        box-shadow: 0 20px 40px rgba(80, 14, 16, 0.08); 
        width: 380px; 
        text-align: center;
        border: 1px solid rgba(215, 96, 103, 0.2);
    }

    .title { font-weight: 700; font-size: 1.1rem; color: #500E10; letter-spacing: 1px; margin-bottom: 8px; }
    
    .info { color: #D76067; font-size: 0.85rem; margin-bottom: 35px; }
    
    .bmi-number { font-size: 6rem; font-weight: 800; color: #500E10; margin: 15px 0; line-height: 1; }

    .category-btn { 
        display: inline-block;
        padding: 14px 35px;
        border-radius: 15px; 
        background-color: <?php echo $data['btn']; ?>; 
        color: <?php echo $data['txt']; ?>;
        font-weight: 700;
        font-size: 0.85rem;
        letter-spacing: 0.5px;
        margin-top: 10px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }

    .footer-text { color: #D76067; opacity: 0.6; font-size: 0.87rem; margin-top: 45px; }
</style>

<div class="bmi-card">
    <div class="title">Body Mass Index (BMI)</div>
    <div class="info">Weight: <?php echo $data['kg']; ?>kg &nbsp;|&nbsp; Height: <?php echo $data['m']; ?>m</div>
    
    <div class="bmi-number"><?php echo $data['val']; ?></div>
    
    <div class="category-btn">
        <?php echo $data['cat']; ?>
    </div>
    
    <div class="footer-text">According to the WHO standards for adults.</div>
</div>