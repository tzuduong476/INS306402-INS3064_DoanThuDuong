<?php
$students = [
    ['name' => 'Nguyen Dieu Linh', 'grade' => 95],
    ['name' => 'Le Tuan Cuong', 'grade' => 82],
    ['name' => 'Pham Thanh Dung', 'grade' => 74],
    ['name' => 'Hoang Thu Thao', 'grade' => 65],
    ['name' => 'Tran Dieu Chau', 'grade' => 88],
];

function getGradeClass($score) {
    if ($score >= 90) return 'grade-a';
    if ($score >= 80) return 'grade-b';
    if ($score >= 70) return 'grade-c';
    return 'grade-f';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student List - Cozy Holiday Theme</title>
    <style>
        :root {
            --eggnog: #D8C8B8;
            --holly-leaf: #616852;
            --mulled-wine: #78211E;
            --cinnamon: #BB9771;
            --frosty: #BEB3AC;
        }

        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background-color: var(--frosty);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }

        .container {
            background: #FFFFFF; 
            padding: 2.5rem;
            border-radius: 40px; 
            box-shadow: 0 20px 60px rgba(97, 104, 82, 0.15);
            width: 95%;
            max-width: 550px;
            border-top: 8px solid var(--mulled-wine);
        }

        h2 {
            text-align: center;
            color: var(--mulled-wine);
            margin-bottom: 2rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            font-size: 1.4rem;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            color: var(--holly-leaf);
            text-align: left;
            padding: 12px 10px;
            font-size: 0.85rem;
            text-transform: uppercase;
            border-bottom: 2px solid var(--eggnog);
        }

        td {
            padding: 15px 10px;
            border-bottom: 1px solid #f0f0f0;
            color: #333;
        }

        tr:hover {
            background-color: rgba(216, 200, 184, 0.2);
            transition: 0.3s;
        }

        .grade-badge {
            padding: 6px 14px;
            border-radius: 20px;
            font-weight: bold;
            font-size: 0.75rem;
            display: inline-block;
        }

        .grade-a { background: var(--mulled-wine); color: #fff; } 
        .grade-b { background: var(--holly-leaf); color: #fff; }
        .grade-c { background: var(--cinnamon); color: #fff; }
        .grade-f { background: var(--eggnog); color: var(--holly-leaf); }

        .student-name {
            color: var(--holly-leaf);
            font-weight: 600;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Student Grade List</h2>
    <table>
        <thead>
            <tr>
                <th>Student Name</th>
                <th>Score</th>
                <th>Rank</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($students as $student): ?>
                <?php 
                    $score = $student['grade'];
                    if ($score >= 90) $rank = "A";
                    elseif ($score >= 80) $rank = "B";
                    elseif ($score >= 70) $rank = "C";
                    else $rank = "F";
                ?>
                <tr>
                    <td class="student-name"><?php echo $student['name']; ?></td>
                    <td style="font-weight: 800; color: var(--mulled-wine);"><?php echo $score; ?></td>
                    <td>
                        <span class="grade-badge <?php echo getGradeClass($score); ?>">
                            Grade: <?php echo $rank; ?>
                        </span>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

</body>
</html>