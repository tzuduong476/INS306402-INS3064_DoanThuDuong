<?php

function isPrime(int $n): bool {
    if ($n < 2) {
        return false;
    }
    
    for ($i = 2; $i <= sqrt($n); $i++) {
        if ($n % $i == 0) {
            return false;
        }
    }
    
    return true;
}

$primes = [];
for ($i = 1; $i <= 100; $i++) {
    if (isPrime($i)) {
        $primes[] = $i;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Prime Seeker - Numbers 1-100</title>
    <style>
        :root {
            --eggnog: #D8C8B8;
            --holly-leaf: #616852;
            --mulled-wine: #78211E;
            --cinnamon: #BB9771;
            --frosty: #BEB3AC;
        }

        body {
            background-color: var(--frosty);
            font-family: 'Segoe UI', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 20px;
        }

        .container {
            background: white;
            padding: 40px;
            border-radius: 40px;
            box-shadow: 0 20px 60px rgba(120, 33, 30, 0.1);
            width: 100%;
            max-width: 600px;
            text-align: center;
            border-top: 8px solid var(--mulled-wine);
        }

        h2 {
            color: var(--mulled-wine);
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-bottom: 10px;
        }

        .subtitle {
            color: var(--holly-leaf);
            font-size: 0.9rem;
            margin-bottom: 30px;
        }

        .prime-grid {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 12px;
        }

        .prime-box {
            background-color: var(--eggnog);
            color: var(--mulled-wine);
            font-weight: 800;
            width: 45px;
            height: 45px;
            display: flex;
            justify-content: center;
            align-items: center;
            border-radius: 12px;
            box-shadow: 0 4px 0 var(--cinnamon);
            transition: transform 0.2s;
        }

        .prime-box:hover {
            transform: translateY(-5px);
            background-color: var(--mulled-wine);
            color: white;
        }

        .footer {
            margin-top: 40px;
            color: var(--cinereous);
            font-size: 0.8rem;
            opacity: 0.7;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Prime Seeker</h2>
    <p class="subtitle">Finding all prime numbers between 1 and 100</p>
    
    <div class="prime-grid">
        <?php 

        
        foreach ($primes as $prime) {
            echo "<div class='prime-box'>$prime</div>";
        }
        ?>
    </div>

    <div class="footer">
        Total primes found: <?php echo count($primes); ?>
    </div>
</div>

</body>
</html>