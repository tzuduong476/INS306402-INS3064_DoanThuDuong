<?php


$scores = [85, 42, 78, 92, 56, 88, 70, 63, 95, 51];

$count = count($scores);
$sum = array_sum($scores);
$average = $sum / $count;
$max_score = max($scores);
$min_score = min($scores);

$top_performers = [];
foreach ($scores as $s) {
    if ($s > $average) {
        $top_performers[] = $s;
    }
}
rsort($top_performers);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Scoreboard - Luxury Palette</title>
    <style>
        :root {
            --wenge: #664C52;
            --rosy-brown: #B99099;
            --platinum: #E8DDDD;
            --liver: #704A4C;
            --puce-red: #762E3F;
        }

        body {
            background-color: var(--platinum);
            font-family: 'Segoe UI', Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            color: var(--wenge);
        }

        .container {
            background: #FFFFFF;
            padding: 45px;
            border-radius: 35px;
            box-shadow: 0 15px 50px rgba(102, 76, 82, 0.15);
            width: 520px;
            text-align: center;
            border-left: 10px solid var(--puce-red); 
        }

        h2 {
            color: var(--puce-red);
            font-size: 2.2rem;
            margin-bottom: 35px;
            text-align: left;
            font-weight: 800;
            letter-spacing: -1px;
        }

        .stats-grid {
            display: flex;
            justify-content: space-between;
            gap: 12px;
            margin-bottom: 40px;
        }

        .stat-box {
            flex: 1;
            padding: 22px 10px;
            background-color: var(--rosy-brown);
            border-radius: 18px;
            color: white;
        }

        .stat-box.main {
            background-color: var(--puce-red);
            box-shadow: 0 8px 20px rgba(118, 46, 63, 0.3);
        }

        .label {
            font-size: 0.7rem;
            font-weight: 600;
            text-transform: uppercase;
            margin-bottom: 8px;
            display: block;
            letter-spacing: 1px;
        }

        .value {
            font-size: 1.5rem;
            font-weight: 700;
        }

        .top-performers {
            text-align: left;
            background-color: var(--wenge);
            padding: 25px;
            border-radius: 20px;
            color: var(--platinum);
        }

        .top-performers h3 {
            font-size: 1rem;
            margin: 0 0 15px 0;
            text-transform: uppercase;
            color: var(--rosy-brown);
        }

        .pills-container {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
        }

        .score-pill {
            background-color: var(--platinum);
            color: var(--puce-red);
            padding: 8px 18px;
            border-radius: 12px;
            font-weight: 800;
            font-size: 1rem;
        }

        .summary-text {
            margin-top: 20px;
            font-size: 0.8rem;
            color: var(--rosy-brown);
            border-top: 1px solid var(--liver);
            padding-top: 15px;
            font-style: italic;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Scoreboard</h2>

    <div class="stats-grid">
        <div class="stat-box">
            <span class="label">Min</span>
            <span class="value"><?php echo $min_score; ?></span>
        </div>
        <div class="stat-box main">
            <span class="label">Average</span>
            <span class="value"><?php echo round($average, 1); ?></span>
        </div>
        <div class="stat-box">
            <span class="label">Max</span>
            <span class="value"><?php echo $max_score; ?></span>
        </div>
    </div>

    <div class="top-performers">
        <h3>Top Performers</h3>
        <div class="pills-container">
            <?php foreach ($top_performers as $score): ?>
                <div class="score-pill"><?php echo $score; ?></div>
            <?php endforeach; ?>
        </div>
        
        <p class="summary-text">
            Analytics Summary: Avg <?php echo round($average, 1); ?> | Min <?php echo $min_score; ?> | Max <?php echo $max_score; ?>
        </p>
    </div>
</div>

</body>
</html>