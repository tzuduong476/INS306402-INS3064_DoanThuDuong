# Part 1: Theory Warm-up Responses

**1. JOIN Distinction:** When a record in the left table has no matching record in the right table, an `INNER JOIN` will exclude that record entirely from the result set. In contrast, a `LEFT JOIN` will include the record from the left table, filling the columns of the unmatched right table with `NULL` values.

**2. Aggregation Logic:**
The `HAVING` clause is specifically designed to filter data *after* it has been grouped and aggregated. We cannot use the `WHERE` clause for aggregate functions like `SUM()` or `COUNT()` because `WHERE` filters individual rows *before* the `GROUP BY` operation occurs.

**3. PDO Definition:**
PDO stands for **PHP Data Objects**. Two primary advantages over the `mysqli` extension are:
* **Database Agnostic:** It supports multiple database drivers (MySQL, PostgreSQL, SQLite, etc.) using the same unified API.
* **Security & OOP:** It offers robust, native support for Prepared Statements and provides a clean Object-Oriented interface.

**4. Security (Prepared Statements):**
Prepared Statements protect against SQL Injection by separating the SQL query structure from the user-provided data. The database engine compiles the SQL query template first. When user inputs are later bound as parameters, they are treated strictly as literal values (text/numbers) and not as executable SQL code, completely neutralizing any malicious SQL commands injected by the user.

**5. Execution Flow:**
The database engine typically evaluates these clauses in the following order:
1.  **WHERE:** Filters individual rows first.
2.  **GROUP BY:** Groups the filtered rows.
3.  **HAVING:** Filters the resulting groups based on aggregate conditions.