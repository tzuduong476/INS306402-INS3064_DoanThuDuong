<?php
require_once 'Database.php';

$db = Database::getInstance()->getConnection();

// 1. Prepare and execute the SQL query
$sql = "SELECT 
            u.name, 
            u.email, 
            SUM(o.total_amount) AS total_spent
        FROM users u
        JOIN orders o ON u.id = o.user_id
        GROUP BY u.id, u.name, u.email
        ORDER BY total_spent DESC
        LIMIT 3";

$stmt = $db->query($sql);

// 2. Fetch the results
$topCustomers = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Top 3 VIP Customers</title>
    <style>
        table { border-collapse: collapse; width: 50%; margin-top: 20px; }
        th, td { padding: 10px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>

    <h2>Top 3 VIP Customers</h2>

    <table border="1">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Total Spent</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($topCustomers as $customer): ?>
                <tr>
                    <td><?= htmlspecialchars($customer['name']) ?></td>
                    <td><?= htmlspecialchars($customer['email']) ?></td>
                    <td>$<?= number_format($customer['total_spent'], 2) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

</body>
</html>