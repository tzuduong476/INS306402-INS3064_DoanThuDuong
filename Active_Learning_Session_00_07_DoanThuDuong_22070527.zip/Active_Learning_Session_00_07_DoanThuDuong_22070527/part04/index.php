<?php
$dsn = "mysql:host=localhost;dbname=product_admin_db;charset=utf8mb4";
$username = "root";
$password = ""; 
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $db = new PDO($dsn, $username, $password, $options);
} catch (PDOException $e) {
    die("Lỗi kết nối cơ sở dữ liệu: " . $e->getMessage());
}

// 1. LẤY DANH MỤC CHO DROPDOWN FILTER
$stmtCategories = $db->query("SELECT id, category_name FROM categories");
$categories = $stmtCategories->fetchAll();

// 2. NHẬN DỮ LIỆU TỪ FORM (GET)
$searchName = isset($_GET['search_name']) ? trim($_GET['search_name']) : '';
$searchCategory = isset($_GET['category_id']) ? $_GET['category_id'] : '';

// 3. CORE VIEW & DYNAMIC SEARCH VỚI PREPARED STATEMENTS
$sql = "SELECT p.id, p.name, p.price, p.stock, c.category_name 
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        WHERE 1=1";

$params = [];

if ($searchName !== '') {
    $sql .= " AND p.name LIKE :search_name";
    $params[':search_name'] = '%' . $searchName . '%';
}

if ($searchCategory !== '') {
    $sql .= " AND p.category_id = :category_id";
    $params[':category_id'] = $searchCategory;
}

$stmt = $db->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Administration Dashboard</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; color: #333; }
        .dashboard-header { background: #f8f9fa; padding: 20px; border-radius: 8px; border: 1px solid #ddd; margin-bottom: 20px; }
        .form-group { display: inline-block; margin-right: 15px; }
        input[type="text"], select { padding: 10px; border: 1px solid #ccc; border-radius: 4px; width: 200px; }
        button { padding: 10px 20px; background-color: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; }
        button:hover { background-color: #0056b3; }
        .reset-btn { text-decoration: none; padding: 10px 20px; background-color: #6c757d; color: white; border-radius: 4px; margin-left: 10px; }
        
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
        th { background-color: #343a40; color: white; }
        
        /* Cảnh báo đỏ cho tồn kho < 10 */
        .stock-alert {
            background-color: #ffcccc;
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <h2>Product Administration Dashboard</h2>

    <div class="dashboard-header">
        <form method="GET" action="index.php">
            <div class="form-group">
                <input type="text" name="search_name" placeholder="Search product name..." value="<?= htmlspecialchars($searchName) ?>">
            </div>
            
            <div class="form-group">
                <select name="category_id">
                    <option value="">-- All Categories --</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat['id'] ?>" <?= ($searchCategory == $cat['id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat['category_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <button type="submit">Filter Products</button>
            <a href="index.php" class="reset-btn">Reset</a>
        </form>
    </div>

    <table>
        <thead>
            <tr>
                <th>Product ID</th>
                <th>Name</th>
                <th>Category</th>
                <th>Price ($)</th>
                <th>Stock Level</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($products) > 0): ?>
                <?php foreach ($products as $row): ?>
                    <?php 
                        $alertClass = ($row['stock'] < 10) ? 'stock-alert' : '';
                    ?>
                    <tr class="<?= $alertClass ?>">
                        <td><?= htmlspecialchars($row['id']) ?></td>
                        <td><?= htmlspecialchars($row['name']) ?></td>
                        <td><?= htmlspecialchars($row['category_name'] ?? 'Uncategorized') ?></td>
                        <td><?= number_format($row['price'], 2) ?></td>
                        <td><?= htmlspecialchars($row['stock']) ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5" style="text-align: center; padding: 20px;">No products found matching your criteria.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

</body>
</html>