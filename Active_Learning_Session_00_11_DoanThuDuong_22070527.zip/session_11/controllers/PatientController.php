<?php
require_once __DIR__ . '/../models/PatientModel.php';

class PatientController {
    private PatientModel $model;

    public function __construct() {
        $this->model = new PatientModel();
    }

    public function index(): void {
        $patients = $this->model->getAll();
        $successMessage = $_GET['success'] ?? '';
        $errorMessage = $_GET['error'] ?? '';
        require __DIR__ . '/../views/patients/index.php';
    }

    public function create(): void {
        $data = ['patient_code' => '', 'full_name' => '', 'date_of_birth' => '', 'gender' => '', 'phone' => '', 'address' => ''];
        $errors = [];
        require __DIR__ . '/../views/patients/create.php';
    }

    public function store(): void {
        $data = [
            'patient_code' => trim($_POST['patient_code'] ?? ''),
            'full_name' => trim($_POST['full_name'] ?? ''),
            'date_of_birth' => trim($_POST['date_of_birth'] ?? ''),
            'gender' => trim($_POST['gender'] ?? ''),
            'phone' => trim($_POST['phone'] ?? ''),
            'address' => trim($_POST['address'] ?? ''),
        ];

        $errors = [];
        if ($data['patient_code'] === '') $errors['patient_code'] = 'Vui lòng nhập Mã bệnh nhân.';
        if ($data['full_name'] === '') $errors['full_name'] = 'Vui lòng nhập Họ Tên.';

        if (!empty($errors)) {
            require __DIR__ . '/../views/patients/create.php';
            return;
        }

        try {
            $this->model->create($data);
            header("Location: index.php?action=index&success=" . urlencode("Thêm bệnh nhân thành công!"));
            exit;
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $errors['patient_code'] = 'Mã bệnh nhân này đã tồn tại!';
            } else {
                $errors['db'] = "Lỗi CSDL: " . $e->getMessage();
            }
            require __DIR__ . '/../views/patients/create.php';
        }
    }

    public function edit(): void {
        $id = (int)($_GET['id'] ?? 0);
        $patient = $this->model->getById($id);
        if (!$patient) {
            header("Location: index.php?action=index");
            exit;
        }
        $data = $patient; 
        $errors = [];
        require __DIR__ . '/../views/patients/edit.php';
    }

    public function update(): void {
        $id = (int)($_POST['id'] ?? 0);
        $data = [
            'patient_code' => trim($_POST['patient_code'] ?? ''),
            'full_name' => trim($_POST['full_name'] ?? ''),
            'date_of_birth' => trim($_POST['date_of_birth'] ?? ''),
            'gender' => trim($_POST['gender'] ?? ''),
            'phone' => trim($_POST['phone'] ?? ''),
            'address' => trim($_POST['address'] ?? ''),
        ];

        $errors = [];
        if ($data['patient_code'] === '') $errors['patient_code'] = 'Vui lòng nhập Mã bệnh nhân.';
        if ($data['full_name'] === '') $errors['full_name'] = 'Vui lòng nhập Họ Tên.';

        if (!empty($errors)) {
            require __DIR__ . '/../views/patients/edit.php';
            return;
        }

        try {
            $this->model->update($id, $data);
            header("Location: index.php?action=index&success=" . urlencode("Cập nhật thành công!"));
            exit;
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $errors['patient_code'] = 'Mã bệnh nhân này đã tồn tại!';
            } else {
                $errors['db'] = "Lỗi CSDL: " . $e->getMessage();
            }
            require __DIR__ . '/../views/patients/edit.php';
        }
    }

    public function delete(): void {
        $id = (int)($_GET['id'] ?? 0);
        try {
            $this->model->delete($id);
            header("Location: index.php?action=index&success=" . urlencode("Đã xóa bệnh nhân thành công!"));
        } catch (PDOException $e) {
            header("Location: index.php?action=index&error=" . urlencode("Lỗi khi xóa: " . $e->getMessage()));
        }
        exit;
    }
}