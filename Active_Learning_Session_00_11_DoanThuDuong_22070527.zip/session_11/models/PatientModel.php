<?php
require_once __DIR__ . '/../config/database.php';

class PatientModel {
    private PDO $pdo;

    public function __construct() {
        $this->pdo = getConnection();
    }

    public function getAll(): array {
        $stmt = $this->pdo->query("SELECT * FROM patients ORDER BY patient_code ASC");
        return $stmt->fetchAll();
    }

    public function getById(int $id) {
        $stmt = $this->pdo->prepare("SELECT * FROM patients WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function create(array $data): bool {
        $stmt = $this->pdo->prepare("INSERT INTO patients (patient_code, full_name, date_of_birth, gender, phone, address) VALUES (?, ?, ?, ?, ?, ?)");
        return $stmt->execute([$data['patient_code'], $data['full_name'], $data['date_of_birth'], $data['gender'], $data['phone'], $data['address']]);
    }

    public function update(int $id, array $data): bool {
        $stmt = $this->pdo->prepare("UPDATE patients SET patient_code=?, full_name=?, date_of_birth=?, gender=?, phone=?, address=? WHERE id=?");
        return $stmt->execute([$data['patient_code'], $data['full_name'], $data['date_of_birth'], $data['gender'], $data['phone'], $data['address'], $id]);
    }

    public function delete(int $id): bool {
        $stmt = $this->pdo->prepare("DELETE FROM patients WHERE id = ?");
        return $stmt->execute([$id]);
    }
}