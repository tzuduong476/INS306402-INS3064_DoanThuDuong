<?php
require_once __DIR__ . '/../controllers/PatientController.php';

$controller = new PatientController();
$action = $_GET['action'] ?? 'index';

$allowedActions = ['index', 'create', 'store', 'edit', 'update', 'delete'];

if (in_array($action, $allowedActions)) {
    $controller->$action();
} else {
    http_response_code(404);
    echo "Trang không tồn tại.";
}