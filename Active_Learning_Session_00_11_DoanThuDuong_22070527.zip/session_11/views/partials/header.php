<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản Lý Bệnh Nhân MVC</title>
    <style>
        :root { --primary-color: #0d6efd; --danger-color: #dc3545; --warning-color: #ffc107; --bg-color: #f8f9fa; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: var(--bg-color); padding: 20px; color: #333; }
        .container { max-width: 1200px; margin: auto; }
        .card { background: #fff; padding: 25px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); margin-bottom: 20px;}
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: 600; color: #495057; }
        input, select { width: 100%; padding: 10px; border: 1px solid #ced4da; border-radius: 6px; box-sizing: border-box; }
        .btn { padding: 10px 20px; border: none; border-radius: 6px; cursor: pointer; color: white; text-decoration: none; font-weight: 600; display: inline-block; text-align: center; box-sizing: border-box;}
        .btn-primary { background: var(--primary-color); }
        .btn-secondary { background: #6c757d; }
        .btn-warning { background: var(--warning-color); color: #000; padding: 6px 12px; }
        .btn-danger { background: var(--danger-color); padding: 6px 12px;}
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { padding: 12px 15px; border-bottom: 1px solid #dee2e6; text-align: left; }
        th { background: #e9ecef; }
        .error { color: var(--danger-color); font-size: 0.85em; display: block; margin-top: 5px;}
        .success { color: #0f5132; background: #d1e7dd; padding: 15px; border-radius: 8px; margin-bottom: 20px; }
        .error-alert { color: #842029; background: #f8d7da; padding: 15px; border-radius: 8px; margin-bottom: 20px; }
    </style>
</head>
<body>
<div class="container">
    <h2 style="text-align: center; color: #2c3e50; margin-bottom: 30px;">Hệ Thống Quản Lý Bệnh Nhân (MVC)</h2>