<?php require __DIR__ . '/../partials/header.php'; ?>

<div class="card" style="max-width: 500px; margin: auto;">
    <h3>Thêm Bệnh nhân mới</h3>
    <?php if (!empty($errors['db'])) echo "<div class='error-alert'>{$errors['db']}</div>"; ?>
    
    <form method="POST" action="index.php?action=store">
        <div class="form-group">
            <label>Mã bệnh nhân *</label>
            <input type="text" name="patient_code" value="<?= htmlspecialchars($data['patient_code']) ?>">
            <?php if (isset($errors['patient_code'])) echo "<span class='error'>{$errors['patient_code']}</span>"; ?>
        </div>
        <div class="form-group">
            <label>Họ và Tên *</label>
            <input type="text" name="full_name" value="<?= htmlspecialchars($data['full_name']) ?>">
            <?php if (isset($errors['full_name'])) echo "<span class='error'>{$errors['full_name']}</span>"; ?>
        </div>
        <div class="form-group">
            <label>Ngày sinh</label>
            <input type="date" name="date_of_birth" value="<?= htmlspecialchars($data['date_of_birth']) ?>">
        </div>
        <div class="form-group">
            <label>Giới tính</label>
            <select name="gender">
                <option value="">-- Chọn giới tính --</option>
                <option value="Male" <?= $data['gender'] == 'Male' ? 'selected' : '' ?>>Nam</option>
                <option value="Female" <?= $data['gender'] == 'Female' ? 'selected' : '' ?>>Nữ</option>
                <option value="Other" <?= $data['gender'] == 'Other' ? 'selected' : '' ?>>Khác</option>
            </select>
        </div>
        <div class="form-group">
            <label>Số điện thoại</label>
            <input type="text" name="phone" value="<?= htmlspecialchars($data['phone']) ?>">
        </div>
        <div class="form-group">
            <label>Địa chỉ</label>
            <input type="text" name="address" value="<?= htmlspecialchars($data['address']) ?>">
        </div>
        <button type="submit" class="btn btn-primary" style="width: 100%; margin-bottom: 10px;">Lưu Dữ Liệu</button>
        <a href="index.php?action=index" class="btn btn-secondary" style="width: 100%;">Hủy bỏ</a>
    </form>
</div>
</body>
</html>