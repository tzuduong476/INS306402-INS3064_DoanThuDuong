<?php require __DIR__ . '/../partials/header.php'; ?>

<?php if ($successMessage): ?>
    <div class="success"><?= htmlspecialchars($successMessage) ?></div>
<?php endif; ?>
<?php if ($errorMessage): ?>
    <div class="error-alert"><?= htmlspecialchars($errorMessage) ?></div>
<?php endif; ?>

<div class="card">
    <div style="display: flex; justify-content: space-between; align-items: center;">
        <h3 style="margin: 0;">Danh Sách Bệnh Nhân</h3>
        <a href="index.php?action=create" class="btn btn-primary">+ Thêm Mới</a>
    </div>
    
    <table>
        <thead>
            <tr>
                <th>Mã BN</th>
                <th>Họ Tên</th>
                <th>Ngày Sinh</th>
                <th>Giới Tính</th>
                <th>Điện Thoại</th>
                <th>Địa chỉ</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($patients as $p): ?>
            <tr>
                <td><strong><?= htmlspecialchars($p['patient_code']) ?></strong></td>
                <td><?= htmlspecialchars($p['full_name']) ?></td>
                <td><?= htmlspecialchars($p['date_of_birth']) ?></td>
                <td>
                    <?php 
                        if($p['gender'] == 'Male') echo 'Nam';
                        elseif($p['gender'] == 'Female') echo 'Nữ';
                        else echo 'Khác';
                    ?>
                </td>
                <td><?= htmlspecialchars($p['phone']) ?></td>
                <td><?= htmlspecialchars($p['address']) ?></td>
                <td>
                    <a href="index.php?action=edit&id=<?= $p['id'] ?>" class="btn btn-warning">Sửa</a>
                    <a href="index.php?action=delete&id=<?= $p['id'] ?>" class="btn btn-danger" onclick="return confirm('Bạn có chắc chắn muốn xóa bệnh nhân này không?');">Xóa</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>
</html>